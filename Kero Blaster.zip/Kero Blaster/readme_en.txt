~ Starting the game ~
Please double-click the .exe file within the game folder.

~ Disclaimer ~
The creator will not be responsible for any loss or damages arising from the usage of this software.
By using the application, you are agreeing to these terms and conditions.

~ Bug reports ~
To report a bug, please contact: https://www.miyakoshuppan.jp/contact

~ Usage rules ~
The redistribution of materials such as illustrations and text without the permission of the rights holder is strictly prohibited.
The redistribution of material without the written consent of the rights holder is copyright infringement.
The rights holder is entitled to seek compensation for any fines or damages arising from the copyright infringement of this material.

~ Game distribution period ~
Distribution of the game may be subject to suspension without prior notice.